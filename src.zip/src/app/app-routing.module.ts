import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ShowstudentsComponent} from './showstudents/showstudents.component'
import {ShowemployeesComponent} from './showemployees/showemployees.component'
import { FormsModule } from '../../node_modules/@angular/forms';
import{ AddEmployeeComponent } from './add-employee/add-employee.component';
import { FormComponent } from './form/form.component';
import {AngularComponent} from './angular/angular.component';
import { LoginComponent } from './login/login.component';


const routes: Routes = [{
  path:'add-employee',
  component: AddEmployeeComponent
},
  {
  path: "showstudents",
 component: ShowstudentsComponent
},
{
  path: "showemployees",
 component: ShowemployeesComponent
},
{
  path:'',
  component: FormComponent
},
{
  path:'angularcomponent',
  component: AngularComponent
},
{
  path:'login',
  component: LoginComponent
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
